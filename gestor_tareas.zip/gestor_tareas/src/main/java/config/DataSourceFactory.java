package config;
//Importamos librerias necesarias
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import javax.sql.DataSource;

public class DataSourceFactory {
    //Declaración de variables
    private static HikariDataSource ds;
    //
    static {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:postgresql://localhost:5432/gestor_tareas");
        config.setUsername("postgres");
        config.setPassword("tu_password");
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        ds = new HikariDataSource(config);
    }

    private DataSourceFactory(){}

    public static DataSource getDataSource() {
        return ds;
    }
}
