package controller;

import dao.UsuarioDAO;
import dao.impl.UsuarioDAOImpl;
import model.Usuario;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Controlador para operaciones de Usuario en patrón MVC.
 */
public class UsuarioController {

    private final UsuarioDAO usuarioDAO;

    public UsuarioController() {
        // Inyectamos la implementación concreta
        this.usuarioDAO = new UsuarioDAOImpl();
    }

    /**
     * Obtiene todos los usuarios.
     */
    public List<Usuario> listarUsuarios() {
        try {
            return usuarioDAO.findAll();
        } catch (Exception e) {
            throw new RuntimeException("Error al listar usuarios", e);
        }
    }

    /**
     * Busca un usuario por su ID.
     */
    public Optional<Usuario> buscarPorId(int id) {
        try {
            return Optional.ofNullable(usuarioDAO.findById(id));
        } catch (Exception e) {
            throw new RuntimeException("Error al buscar usuario por ID", e);
        }
    }

    /**
     * Busca un usuario por nombre de usuario.
     */
    public Optional<Usuario> buscarPorNombre(String nombre) {
        try {
            return Optional.ofNullable(usuarioDAO.findByNombre(nombre));
        } catch (Exception e) {
            throw new RuntimeException("Error al buscar usuario por nombre", e);
        }
    }

    /**
     * Crea un nuevo usuario.
     */
    public Usuario crearUsuario(String nombre, String contrasena, String email, String rol) {
        try {
            // Creamos el objeto Usuario y asignamos solo lo necesario
            Usuario u = new Usuario();
            u.setNombreUsuario(nombre);
            u.setContrasena(contrasena);
            u.setEmail(email);
            u.setRol(rol);
            // Podemos definir fechaRegistro y ultimaConexion desde Java si queremos:
            OffsetDateTime ahora = OffsetDateTime.now();
            u.setFechaRegistro(ahora);
            u.setUltimaConexion(ahora);
            // Delegamos al DAO (el DAO llenará el id retornado por la BD)
            usuarioDAO.create(u);
            return u;
        } catch (Exception e) {
            throw new RuntimeException("Error al crear usuario", e);
        }
    }

    /**
     * Actualiza un usuario existente.
     */
    public Usuario actualizarUsuario(int id, String nombre, String contrasena, String email, String rol) {
        try {
            Usuario u = usuarioDAO.findById(id);
            if (u == null) {
                throw new IllegalArgumentException("Usuario con ID " + id + " no existe");
            }
            u.setNombreUsuario(nombre);
            u.setContrasena(contrasena);
            u.setEmail(email);
            u.setRol(rol);
            // Actualizamos la última conexión
            u.setUltimaConexion(OffsetDateTime.now());
            usuarioDAO.update(u);
            return u;
        } catch (Exception e) {
            throw new RuntimeException("Error al actualizar usuario", e);
        }
    }

    /**
     * Elimina un usuario por su ID.
     */
    public void eliminarUsuario(int id) {
        try {
            usuarioDAO.delete(id);
        } catch (Exception e) {
            throw new RuntimeException("Error al eliminar usuario", e);
        }
    }
}
