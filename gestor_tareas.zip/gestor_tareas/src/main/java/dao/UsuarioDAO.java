package dao;
//Importar librerias necesarias
import model.Usuario;
import java.util.List;
//Creamos la interfaz del usuario
public interface UsuarioDAO {
    Usuario findById(int id) throws Exception;
    Usuario findByNombre(String nombre) throws Exception;
    List<Usuario> findAll() throws Exception;
    void create(Usuario u) throws Exception;
    void update(Usuario u) throws Exception;
    void delete(int id) throws Exception;
}
