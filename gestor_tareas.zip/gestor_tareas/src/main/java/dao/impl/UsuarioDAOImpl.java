package dao.impl;
//Importar librerias
import config.DataSourceFactory;
import dao.UsuarioDAO;
import model.Usuario;
import javax.sql.DataSource;
import java.sql.*;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
//
public class UsuarioDAOImpl implements UsuarioDAO {
    private final DataSource ds = DataSourceFactory.getDataSource();

    @Override
    public Usuario findById(int id) throws SQLException {
        String sql = "SELECT * FROM public.usuarios WHERE id_usuario = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    @Override
    public Usuario findByNombre(String nombre) throws SQLException {
        String sql = "SELECT * FROM public.usuarios WHERE nombre_usuario = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, nombre);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    @Override
    public List<Usuario> findAll() throws SQLException {
        String sql = "SELECT * FROM public.usuarios ORDER BY id_usuario";
        List<Usuario> lista = new ArrayList<>();
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(map(rs));
            }
        }
        return lista;
    }

    @Override
    public void create(Usuario u) throws SQLException {
        String sql = "INSERT INTO public.usuarios (nombre_usuario, contrasena, email, rol, fecha_registro, ultima_conexion) " +
                     "VALUES (?, ?, ?, ?, ?, ?) RETURNING id_usuario";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, u.getNombreUsuario());
            ps.setString(2, u.getContrasena());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getRol());
            ps.setObject(5, u.getFechaRegistro());
            ps.setObject(6, u.getUltimaConexion());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    u.setId(rs.getInt(1));
                }
            }
        }
    }

    @Override
    public void update(Usuario u) throws SQLException {
        String sql = "UPDATE public.usuarios SET nombre_usuario = ?, contrasena = ?, email = ?, rol = ?, ultima_conexion = ? " +
                     "WHERE id_usuario = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, u.getNombreUsuario());
            ps.setString(2, u.getContrasena());
            ps.setString(3, u.getEmail());
            ps.setString(4, u.getRol());
            ps.setObject(5, u.getUltimaConexion());
            ps.setInt(6, u.getId());
            ps.executeUpdate();
        }
    }

    @Override
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM public.usuarios WHERE id_usuario = ?";
        try (Connection c = ds.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    /**
     * Mapea un ResultSet a un objeto Usuario.
     */
    private Usuario map(ResultSet rs) throws SQLException {
    Usuario u = new Usuario(
        rs.getInt("id_usuario"),
        rs.getString("nombre_usuario"),
        rs.getString("contrasena"),
        rs.getString("email"),
        rs.getString("rol"),
        rs.getObject("fecha_registro", OffsetDateTime.class),
        rs.getObject("ultima_conexion", OffsetDateTime.class)
    );
        u.setId(rs.getInt("id_usuario"));
        u.setNombreUsuario(rs.getString("nombre_usuario"));
        u.setContrasena(rs.getString("contrasena"));
        u.setEmail(rs.getString("email"));
        u.setRol(rs.getString("rol"));
        u.setFechaRegistro(rs.getObject("fecha_registro", OffsetDateTime.class));
        u.setUltimaConexion(rs.getObject("ultima_conexion", OffsetDateTime.class));
        return u;
    }
}
