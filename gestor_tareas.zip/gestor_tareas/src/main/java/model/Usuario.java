package model;

import java.io.Serializable;
import java.time.OffsetDateTime;

public class Usuario implements Serializable {
    private Integer id;
    private String nombreUsuario;
    private String contrasena;
    private String email;
    private String rol;
    private OffsetDateTime fechaRegistro;
    private OffsetDateTime ultimaConexion;

    // Constructor sin parámetros
    public Usuario() {
        // Inicialización por defecto si es necesario
    }

    // Constructor con parámetros
    public Usuario(Integer id, String nombreUsuario, String contrasena, String email, String rol,
                   OffsetDateTime fechaRegistro, OffsetDateTime ultimaConexion) {
        this.id = id;
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.email = email;
        this.rol = rol;
        this.fechaRegistro = fechaRegistro;
        this.ultimaConexion = ultimaConexion;
    }

    // Getters y setters...
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public OffsetDateTime getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(OffsetDateTime fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public OffsetDateTime getUltimaConexion() {
        return ultimaConexion;
    }

    public void setUltimaConexion(OffsetDateTime ultimaConexion) {
        this.ultimaConexion = ultimaConexion;
    }
}
