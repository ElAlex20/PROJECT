
package view;

/**
 *
 * @author AlexN
 */
public class NewClass {
    
}
